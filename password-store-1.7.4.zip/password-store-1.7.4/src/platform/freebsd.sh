# Copyright (C) 2012 Jonathan Chu <milki@rescomp.berkeley.edu>. All Rights Reserved.
# This file is licensed under the GPLv2+. Please see COPYING for more information.

GETOPT="/usr/local/bin/getopt"
SHRED="rm -P -f"
BASE64="openssl base64"
